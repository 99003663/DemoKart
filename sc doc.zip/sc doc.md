﻿**Project Scope:**

The objective of this project is to develop a general purpose e-commerce store where product like clothes, electronics, groceries and accessories  can be bought from the comfort of home through the Internet. 

**Project Description**:

E-commerce is fast gaining ground as an accepted and used business paradigm. More and more business houses are implementing web sites providing functionality for performing commercial transactions over the web. It is reasonable to say that the process of shopping on the web is becoming common place.

**SWOT ANALYSIS**

**Strengths  :**

- Broad range of products
- Own Logistics services
- Own payment gateway
- COD available on all items

## **Weaknesses :**
- ## No return policy.
- ## Shipping charges could be high sometimes
- ## There might be a delay in delivering products sometimes.
## **Opportunities :**
- ## Expanding the product range.
- ## Expansion of business.
## 
## `   `**Threats  :**
- ## Stiff competition from the other e commerce companies.
- ## Many customers are reluctant to pay online.
- ## Customers continue to have concerns about online services in relation to fraudulent use of their financial data.
##
##





