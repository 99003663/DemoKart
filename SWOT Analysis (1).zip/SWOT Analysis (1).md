﻿**SWOT ANALYSIS**

**Strengths  :**

- Broad range of products
- Own Logistics services
- Own payment gateway
- COD available on all items

## **Weaknesses :**
- ## No return policy.
- ## Shipping charges could be high sometimes
- ## There might be a delay in delivering products sometimes.
## **Opportunities :**
- ## Expanding the product range.
- ## Expansion of business.
## 
## `   `**Threats  :**
- ## Stiff competition from the other e commerce companies.
- ## Many customers are reluctant to pay online.
- ## Customers continue to have concerns about online services in relation to fraudulent use of their financial data.
##
##




